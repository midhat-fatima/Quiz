<?php
/**
 * Thrive Themes - https://thrivethemes.com
 *
 * @package thrive-visual-editor
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Silence is golden!
}
?>
<div class="thrv_wrapper thrv-button">
	<a href="#" class="tcb-button-link">
		<span class="tcb-button-texts"><span class="tcb-button-text thrv-inline-text"> Default Button Text </span></span>
	</a>
</div>
