<?php
/**
 * Created by PhpStorm.
 * User: Ovidiu
 * Date: 4/10/2017
 * Time: 10:27 AM
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Silence is golden!
}
?>
<div class="thrv_wrapper tve_wp_shortcode tcb-elem-placeholder">
	<span class="tcb-inline-placeholder-action with-icon">
		<?php tcb_icon( 'wordpress', false, 'editor' ); ?>
		<?php echo __( 'Insert WordPress Content', 'thrive-cb' ); ?>
	</span>
</div>
