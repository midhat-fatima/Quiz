<div class="inline-checkboxes">
	<label class="tcb-checkbox">
		<input type="checkbox" class="change" data-fn="extraSettingsChanged" data-elem-attr="data-autoplay" data-elem-attr-val="1" data-elem-attr-val-unchecked="0"><span><?php echo __( 'Autoplay', 'thrive-cb' ) ?></span>
	</label>
</div>
<div class="inline-checkboxes">
	<label class="tcb-checkbox">
		<input type="checkbox" class="change" data-fn="extraSettingsChanged" data-elem-attr="loop" data-elem-attr-val="1" data-elem-attr-val-unchecked="0"><span><?php echo __( 'Loop', 'thrive-cb' ) ?></span>
	</label>
</div>
