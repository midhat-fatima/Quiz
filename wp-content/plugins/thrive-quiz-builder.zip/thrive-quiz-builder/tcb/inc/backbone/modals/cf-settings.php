<div class="tcb-flex flex-dir-column h-100">
	<h2 class="tcb-modal-title"><?php echo __( 'Email & after submit setup' ); ?></h2>

	<div class="clearfix pb-10 tcb-cf-modal-content">
		<div class="tcb-modal-steps"></div>
	</div>
</div>
<div class="tcb-modal-footer pt-20 control-grid">
	<button type="button" class="tcb-left tve-button text-only tcb-modal-cancel">
		<?php echo __( 'Cancel', 'thrive-cb' ); ?>
	</button>
	<button type="button" class="tcb-right tve-button medium tcb-modal-save">
		<?php echo __( 'Next', 'thrive-cb' ); ?>
	</button>
</div>